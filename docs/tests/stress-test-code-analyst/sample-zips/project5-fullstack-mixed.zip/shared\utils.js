﻿// Shared utilities
const formatDate = (date) => {
    return new Date(date).toLocaleDateString();
};

const validateEmail = (email) => {
    return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
};

module.exports = { formatDate, validateEmail };
