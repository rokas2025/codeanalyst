﻿const express = require('express');
const cors = require('cors');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// API Routes
app.get('/api/health', (req, res) => {
    res.json({ status: 'OK', timestamp: new Date() });
});

app.get('/api/data', (req, res) => {
    res.json({
        items: [
            { id: 1, title: 'Item 1', description: 'First item' },
            { id: 2, title: 'Item 2', description: 'Second item' },
            { id: 3, title: 'Item 3', description: 'Third item' }
        ]
    });
});

app.post('/api/data', (req, res) => {
    const { title, description } = req.body;
    res.status(201).json({ id: 4, title, description });
});

// Serve static files in production
if (process.env.NODE_ENV === 'production') {
    app.use(express.static(path.join(__dirname, '../frontend/build')));
    app.get('*', (req, res) => {
        res.sendFile(path.join(__dirname, '../frontend/build/index.html'));
    });
}

app.listen(PORT, () => {
    console.log(Backend server running on port );
});
