﻿// Shared constants
const API_VERSION = 'v1';
const MAX_ITEMS = 100;
const CACHE_DURATION = 3600;

module.exports = { API_VERSION, MAX_ITEMS, CACHE_DURATION };
