﻿# Full-Stack Test Application

This is a full-stack application with Express backend and vanilla JS frontend.

## Structure
- /backend - Express.js API server
- /frontend - Static HTML/CSS/JS frontend
- /shared - Shared utilities and constants

## Running
npm install
npm start

## Features
- RESTful API
- Data fetching
- Modern UI
