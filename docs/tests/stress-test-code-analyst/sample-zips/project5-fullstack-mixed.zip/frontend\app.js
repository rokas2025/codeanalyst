﻿const API_URL = 'http://localhost:5000/api';

document.getElementById('loadBtn').addEventListener('click', async () => {
    try {
        const response = await fetch(${API_URL}/data);
        const data = await response.json();
        
        const container = document.getElementById('dataContainer');
        container.innerHTML = '<ul>' + 
            data.items.map(item => 
                <li><strong></strong>: </li>
            ).join('') + 
            '</ul>';
    } catch (error) {
        console.error('Error loading data:', error);
    }
});

// Check health on load
fetch(${API_URL}/health)
    .then(res => res.json())
    .then(data => console.log('Backend health:', data))
    .catch(err => console.error('Backend not available:', err));
