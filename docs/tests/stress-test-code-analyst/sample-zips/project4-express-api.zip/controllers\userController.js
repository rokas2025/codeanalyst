﻿const User = require('../models/User');

exports.getAllUsers = (req, res) => {
    // TODO: Fetch from database
    const users = [
        { id: 1, name: 'John Doe', email: 'john@example.com' },
        { id: 2, name: 'Jane Smith', email: 'jane@example.com' }
    ];
    res.json(users);
};

exports.getUserById = (req, res) => {
    const userId = req.params.id;
    // TODO: Fetch from database
    res.json({ id: userId, name: 'User ' + userId });
};

exports.createUser = (req, res) => {
    const { name, email } = req.body;
    // TODO: Validate and save to database
    res.status(201).json({ id: 3, name, email });
};

exports.updateUser = (req, res) => {
    const userId = req.params.id;
    const { name, email } = req.body;
    // TODO: Update in database
    res.json({ id: userId, name, email });
};

exports.deleteUser = (req, res) => {
    const userId = req.params.id;
    // TODO: Delete from database
    res.json({ message: 'User deleted', id: userId });
};
