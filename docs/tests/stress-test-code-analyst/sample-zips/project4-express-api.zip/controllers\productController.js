﻿const Product = require('../models/Product');

exports.getAllProducts = (req, res) => {
    const products = [
        { id: 1, name: 'Laptop', price: 999 },
        { id: 2, name: 'Phone', price: 599 }
    ];
    res.json(products);
};

exports.getProductById = (req, res) => {
    const productId = req.params.id;
    res.json({ id: productId, name: 'Product ' + productId, price: 100 });
};

exports.createProduct = (req, res) => {
    const { name, price } = req.body;
    res.status(201).json({ id: 3, name, price });
};
