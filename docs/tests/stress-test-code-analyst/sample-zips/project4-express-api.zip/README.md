﻿# Express API Test

REST API built with Express.js for testing purposes.

## Endpoints
- GET /api/users - Get all users
- GET /api/users/:id - Get user by ID
- POST /api/users - Create new user
- GET /api/products - Get all products
