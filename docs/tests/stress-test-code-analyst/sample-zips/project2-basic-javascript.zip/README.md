﻿# Basic JS App

This is a test application for code analysis.

## Installation
npm install

## Usage
npm start
