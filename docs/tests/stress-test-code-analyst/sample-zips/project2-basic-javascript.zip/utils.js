﻿// Utility functions
function formatDate(date) {
    return date.toISOString().split('T')[0];
}

function validateEmail(email) {
    // Simple email validation
    return email.includes('@');
}

module.exports = { formatDate, validateEmail };
