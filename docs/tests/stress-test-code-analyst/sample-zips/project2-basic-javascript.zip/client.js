﻿// Client-side JavaScript
document.addEventListener('DOMContentLoaded', function() {
    fetch('/api/users')
        .then(response => response.json())
        .then(data => {
            const app = document.getElementById('app');
            app.innerHTML = '<ul>' + 
                data.map(user => '<li>' + user.name + '</li>').join('') + 
                '</ul>';
        });
});
