﻿import React, { useState, useEffect } from 'react';
import './App.css';
import UserList from './components/UserList';

function App() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    // Simulated API call
    setTimeout(() => {
      setUsers([
        { id: 1, name: 'Alice', email: 'alice@test.com' },
        { id: 2, name: 'Bob', email: 'bob@test.com' }
      ]);
      setLoading(false);
    }, 1000);
  }, []);

  return (
    <div className="App">
      <header className="App-header">
        <h1>React Test Application</h1>
        {loading ? (
          <p>Loading...</p>
        ) : (
          <UserList users={users} />
        )}
      </header>
    </div>
  );
}

export default App;
